import os

# Main Settings

os.environ["SECRET_KEY"] = "DjangoKey12356"
os.environ["DEBUG"] = "0"
# Audd.io API Key
os.environ["api_token"] = "dbca325b7143f37f12635f7d28fd5355"

# S3 Upload
os.environ["AWS_ACCESS_KEY_ID"] = 'AKIAWXOZMZ76VACKYXPW'
os.environ["AWS_SECRET_ACCESS_KEY"] = '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'
os.environ["AWS_STORAGE_BUCKET_NAME"] = 'elasticbeanstalk-eu-west-1-462701776893'
os.environ["AWS_S3_REGION_NAME"] = 'eu-west-1'
